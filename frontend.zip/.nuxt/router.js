import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2321f225 = () => interopDefault(import('..\\pages\\agenda\\index.vue' /* webpackChunkName: "pages/agenda/index" */))
const _47176320 = () => interopDefault(import('..\\pages\\atencion\\index.vue' /* webpackChunkName: "pages/atencion/index" */))
const _75ed6d88 = () => interopDefault(import('..\\pages\\configuracion\\index.vue' /* webpackChunkName: "pages/configuracion/index" */))
const _51497ae5 = () => interopDefault(import('..\\pages\\consultas\\index.vue' /* webpackChunkName: "pages/consultas/index" */))
const _4ec35079 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _e5337970 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _3d37b5fd = () => interopDefault(import('..\\pages\\mensajes\\index.vue' /* webpackChunkName: "pages/mensajes/index" */))
const _975fee5c = () => interopDefault(import('..\\pages\\otros\\index.vue' /* webpackChunkName: "pages/otros/index" */))
const _6a9201d0 = () => interopDefault(import('..\\pages\\productos\\index.vue' /* webpackChunkName: "pages/productos/index" */))
const _ee94be6a = () => interopDefault(import('..\\pages\\socios\\index.vue' /* webpackChunkName: "pages/socios/index" */))
const _320c3977 = () => interopDefault(import('..\\pages\\venta\\index.vue' /* webpackChunkName: "pages/venta/index" */))
const _a052ea56 = () => interopDefault(import('..\\pages\\atencion\\index copy.vue' /* webpackChunkName: "pages/atencion/index copy" */))
const _687f94cc = () => interopDefault(import('..\\pages\\productos\\listado.vue' /* webpackChunkName: "pages/productos/listado" */))
const _7473f64a = () => interopDefault(import('..\\pages\\productos\\venta.vue' /* webpackChunkName: "pages/productos/venta" */))
const _b097296c = () => interopDefault(import('..\\pages\\socios\\registro.vue' /* webpackChunkName: "pages/socios/registro" */))
const _fbbc3fe6 = () => interopDefault(import('..\\pages\\productos\\editar\\_id_product.vue' /* webpackChunkName: "pages/productos/editar/_id_product" */))
const _230ab106 = () => interopDefault(import('..\\pages\\socios\\editar\\_id_socio.vue' /* webpackChunkName: "pages/socios/editar/_id_socio" */))
const _7882bf9e = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/agenda",
    component: _2321f225,
    name: "agenda"
  }, {
    path: "/atencion",
    component: _47176320,
    name: "atencion"
  }, {
    path: "/configuracion",
    component: _75ed6d88,
    name: "configuracion"
  }, {
    path: "/consultas",
    component: _51497ae5,
    name: "consultas"
  }, {
    path: "/inspire",
    component: _4ec35079,
    name: "inspire"
  }, {
    path: "/login",
    component: _e5337970,
    name: "login"
  }, {
    path: "/mensajes",
    component: _3d37b5fd,
    name: "mensajes"
  }, {
    path: "/otros",
    component: _975fee5c,
    name: "otros"
  }, {
    path: "/productos",
    component: _6a9201d0,
    name: "productos"
  }, {
    path: "/socios",
    component: _ee94be6a,
    name: "socios"
  }, {
    path: "/venta",
    component: _320c3977,
    name: "venta"
  }, {
    path: "/atencion/index%20copy",
    component: _a052ea56,
    name: "atencion-index copy"
  }, {
    path: "/productos/listado",
    component: _687f94cc,
    name: "productos-listado"
  }, {
    path: "/productos/venta",
    component: _7473f64a,
    name: "productos-venta"
  }, {
    path: "/socios/registro",
    component: _b097296c,
    name: "socios-registro"
  }, {
    path: "/productos/editar/:id_product?",
    component: _fbbc3fe6,
    name: "productos-editar-id_product"
  }, {
    path: "/socios/editar/:id_socio?",
    component: _230ab106,
    name: "socios-editar-id_socio"
  }, {
    path: "/",
    component: _7882bf9e,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
