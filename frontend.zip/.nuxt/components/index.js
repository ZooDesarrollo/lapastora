export const ModalSuccess = () => import('../..\\components\\modalSuccess.vue' /* webpackChunkName: "components/modal-success" */).then(c => wrapFunctional(c.default || c))
export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const VuetifyLogo = () => import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components/vuetify-logo" */).then(c => wrapFunctional(c.default || c))
export const AgendaCalendarComponent = () => import('../..\\components\\agenda\\calendarComponent.vue' /* webpackChunkName: "components/agenda-calendar-component" */).then(c => wrapFunctional(c.default || c))
export const GeneralToolbarComponent = () => import('../..\\components\\general\\toolbarComponent.vue' /* webpackChunkName: "components/general-toolbar-component" */).then(c => wrapFunctional(c.default || c))
export const ProductosHistorialProductosComponent = () => import('../..\\components\\productos\\historialProductosComponent.vue' /* webpackChunkName: "components/productos-historial-productos-component" */).then(c => wrapFunctional(c.default || c))
export const ProductosListComponent = () => import('../..\\components\\productos\\productosListComponent.vue' /* webpackChunkName: "components/productos-list-component" */).then(c => wrapFunctional(c.default || c))
export const SociosFindSociosComponent = () => import('../..\\components\\socios\\findSociosComponent.vue' /* webpackChunkName: "components/socios-find-socios-component" */).then(c => wrapFunctional(c.default || c))
export const SociosFormSociosComponent = () => import('../..\\components\\socios\\formSociosComponent.vue' /* webpackChunkName: "components/socios-form-socios-component" */).then(c => wrapFunctional(c.default || c))
export const SociosListSociosComponent = () => import('../..\\components\\socios\\listSociosComponent.vue' /* webpackChunkName: "components/socios-list-socios-component" */).then(c => wrapFunctional(c.default || c))
export const UsuariosInfoUserComponent = () => import('../..\\components\\usuarios\\infoUserComponent.vue' /* webpackChunkName: "components/usuarios-info-user-component" */).then(c => wrapFunctional(c.default || c))
export const VentasListComponent = () => import('../..\\components\\ventas\\ventasListComponent.vue' /* webpackChunkName: "components/ventas-list-component" */).then(c => wrapFunctional(c.default || c))
export const VisitasDataComponent = () => import('../..\\components\\visitas\\visitasDataComponent.vue' /* webpackChunkName: "components/visitas-data-component" */).then(c => wrapFunctional(c.default || c))
export const VisitasListComponent = () => import('../..\\components\\visitas\\visitasListComponent.vue' /* webpackChunkName: "components/visitas-list-component" */).then(c => wrapFunctional(c.default || c))
export const VisitasProductosComponent = () => import('../..\\components\\visitas\\visitasProductosComponent.vue' /* webpackChunkName: "components/visitas-productos-component" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
