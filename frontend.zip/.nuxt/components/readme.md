# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<ModalSuccess>` | `<modal-success>` (components/modalSuccess.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<VuetifyLogo>` | `<vuetify-logo>` (components/VuetifyLogo.vue)
- `<AgendaCalendarComponent>` | `<agenda-calendar-component>` (components/agenda/calendarComponent.vue)
- `<GeneralToolbarComponent>` | `<general-toolbar-component>` (components/general/toolbarComponent.vue)
- `<ProductosHistorialProductosComponent>` | `<productos-historial-productos-component>` (components/productos/historialProductosComponent.vue)
- `<ProductosListComponent>` | `<productos-list-component>` (components/productos/productosListComponent.vue)
- `<SociosFindSociosComponent>` | `<socios-find-socios-component>` (components/socios/findSociosComponent.vue)
- `<SociosFormSociosComponent>` | `<socios-form-socios-component>` (components/socios/formSociosComponent.vue)
- `<SociosListSociosComponent>` | `<socios-list-socios-component>` (components/socios/listSociosComponent.vue)
- `<UsuariosInfoUserComponent>` | `<usuarios-info-user-component>` (components/usuarios/infoUserComponent.vue)
- `<VentasListComponent>` | `<ventas-list-component>` (components/ventas/ventasListComponent.vue)
- `<VisitasDataComponent>` | `<visitas-data-component>` (components/visitas/visitasDataComponent.vue)
- `<VisitasListComponent>` | `<visitas-list-component>` (components/visitas/visitasListComponent.vue)
- `<VisitasProductosComponent>` | `<visitas-productos-component>` (components/visitas/visitasProductosComponent.vue)
