export default {"theme":{"dark":false,"themes":{"light":{"primary":"#03989e","accent":"#424242","secondary":"#ff8f00","info":"#26a69a","warning":"#ffc107","error":"#dd2c00","success":"#00e676"}}}}
