<template>
  <v-row justify="center" align="center">
  </v-row>
</template>

<script>
export default {
  mounted() {
    this.$router.push('/venta')
  }
}
</script>